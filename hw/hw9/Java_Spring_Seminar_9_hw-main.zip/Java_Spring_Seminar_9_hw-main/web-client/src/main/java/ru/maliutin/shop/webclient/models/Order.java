package ru.maliutin.shop.webclient.models;

/**
 * Объект с заказом товара.
 */
public record Order(int amount) {
}
