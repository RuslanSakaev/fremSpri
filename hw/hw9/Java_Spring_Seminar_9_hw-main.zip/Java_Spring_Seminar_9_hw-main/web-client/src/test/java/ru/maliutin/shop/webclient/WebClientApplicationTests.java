package ru.maliutin.shop.webclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
