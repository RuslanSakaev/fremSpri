package ru.maliutin.shop.productstorage.models;

import lombok.Data;

/**
 * Обертка заказа.
 */
@Data
public class Order {

    private int amount;

}
