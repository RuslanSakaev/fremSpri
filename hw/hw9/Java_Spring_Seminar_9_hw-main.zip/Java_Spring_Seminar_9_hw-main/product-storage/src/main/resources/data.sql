insert into product (name, price, amount, reserved)
values ('iphone 12', 89000.00, 10, 0),
       ('Samsung S22+', 10000.00, 10, 0);