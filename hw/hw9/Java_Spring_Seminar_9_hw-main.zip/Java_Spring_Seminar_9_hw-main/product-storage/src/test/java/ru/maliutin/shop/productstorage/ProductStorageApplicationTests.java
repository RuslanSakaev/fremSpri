package ru.maliutin.shop.productstorage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductStorageApplicationTests {

    @Test
    void contextLoads() {
    }

}
