insert into bank_account (number, balance)
values (1, 100000),
       (2, 50000),
       (3, 0);